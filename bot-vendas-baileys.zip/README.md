# 🤖 Bot de Vendas WhatsApp com Baileys (Render Ready)

Este é um bot completo de vendas para WhatsApp usando [Baileys](https://github.com/WhiskeySockets/Baileys), sem necessidade de APIs pagas como Z-API. Ele funciona diretamente via WhatsApp Web (conexão com QR Code) e pode ser hospedado gratuitamente no [Render.com](https://render.com).

## ✅ Funcionalidades
- Catálogo de produtos via `#menu`
- Pedido via `#comprar <produto> <quantidade>`
- Geração de QR Code Pix automático
- Registro dos pedidos em uma planilha do Google
- Painel Web protegido para acompanhar pedidos

## 🚀 Como usar

### 1. Faça o deploy no Render

1. Crie uma conta gratuita no [Render](https://render.com/)
2. Crie um novo Web Service e conecte este repositório do GitHub
3. Escolha:
   - Runtime: Node.js
   - Build command: `npm install`
   - Start command: `node index.js`

### 2. Configure variáveis de ambiente no Render

- `PIX_CHAVE`: sua chave Pix
- `NOME_RECEBEDOR`: nome do recebedor
- `GOOGLE_SHEET_ID`: ID da planilha do Google
- `PAINEL_SENHA`: senha do painel `/painel`
- `SESSION_FILE`: nome do arquivo de sessão (ex: `baileys_session.json`)

### 3. Ao iniciar pela primeira vez

- O terminal do Render mostrará um link com o QR Code
- Escaneie com seu WhatsApp para conectar

### 4. Acesse o painel

```
https://<seu-subdomínio>.onrender.com/painel?senha=SUASENHA
```

## 📂 Estrutura do projeto

- `index.js`: Código principal
- `produtos.json`: Catálogo de produtos
- `painel.html`: Interface simples para pedidos
- `google-auth/service_account.json`: Chave do Google Sheets

---

Criado para uso gratuito, simples e prático. Suporte a múltiplos comandos e integração com o Pix.
